#include <iostream>
#include <iomanip> 
#include <string>
#include <cctype> 

using namespace std;

// Function prototype
double extractNumeric(const string& str);

int main() {
    string input;

    while (true) {
        // Prompt the user for input
        cout << "Enter a string (or 'END' to quit): ";
        cin >> input;

        // Check for termination condition
        if (input == "END") {
            break;
        }

        // Extract the numeric value
        double number = extractNumeric(input);

        // Display the result
        if (number != -999999.99) {
            cout << "The input is: " << fixed << setprecision(4) << number << endl;
        } else {
            cout << "The input is invalid." << endl;
        }
    }

    return 0;
}

// Function to extract a numeric value from a string
double extractNumeric(const string& str) {
    // Constants
    const double INVALID_RESULT = -999999.99;

    // Check if the string is empty or too long
    if (str.empty() || str.length() > 20) {
        return INVALID_RESULT;
    }

    // Flags and variables for parsing
    bool hasSign = false;       
    bool hasDecimal = false;    
    bool hasDigits = false;     
    double result = 0.0;        
    double fractionalPart = 0.0; 
    int sign = 1;               
    size_t decimalPos = string::npos; 

    // Loop through each character in the string
    for (size_t i = 0; i < str.length(); ++i) {
        char ch = str[i];

        if (i == 0 && (ch == '+' || ch == '-')) {
            
            hasSign = true;
            if (ch == '-') {
                sign = -1;
            }
        } else if (ch == '.' && !hasDecimal) {
            
            hasDecimal = true;
            decimalPos = i;
        } else if (isdigit(ch)) {
            
            hasDigits = true;
        } else {
            
            return INVALID_RESULT;
        }
    }

    
    if (!hasDigits || (hasDecimal && str.length() == 1)) {
        return INVALID_RESULT;
    }

    // Parse the integer part
    size_t start = (hasSign ? 1 : 0);
    for (size_t j = start; j < (decimalPos == string::npos ? str.length() : decimalPos); ++j) {
        result = result * 10 + (str[j] - '0');
    }

    // Parse the fractional part (if any)
    if (hasDecimal) {
        double divisor = 10.0;
        for (size_t j = decimalPos + 1; j < str.length(); ++j) {
            fractionalPart += (str[j] - '0') / divisor;
            divisor *= 10;
        }
    }

    // Combine the integer and fractional parts, applying the sign
    result = sign * (result + fractionalPart);

    return result;
}
