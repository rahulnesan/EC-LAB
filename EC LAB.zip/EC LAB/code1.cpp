#include <iostream>
#include <string>
#include <iomanip>

// Function to extract a double-precision number from a string
double extractNumeric(const std::string& input) {
    bool decimalPointFound = false;
    bool isValid = true;
    bool signAllowed = true;  
    std::string numericPart = "";  

    for (size_t i = 0; i < input.length(); ++i) {
        char c = input[i];

        if (c == '+' || c == '-') {
            if (signAllowed) {
                numericPart += c;
                signAllowed = false;  
            } else {
                isValid = false;  
                break;
            }
        } else if (c == '.') {
            if (!decimalPointFound) {
                decimalPointFound = true;
                numericPart += c;
            } else {
                isValid = false;  
                break;
            }
        } else if (isdigit(c)) {
            numericPart += c;
            signAllowed = false;  
        } else {
            isValid = false;  
            break;
        }
    }

    // Check for cases like ".", "+", "-", "+.", "-." which are not valid numbers
    if (numericPart.empty() || numericPart == "+" || numericPart == "-" || numericPart == "." ||
        numericPart == "+." || numericPart == "-.") {
        isValid = false;
    }

    if (isValid) {
        // Convert the valid string to a double
        double result = 0.0;
        try {
            result = std::stod(numericPart);
        } catch (...) {
            return -999999.99;  
        }
        return result;
    } else {
        return -999999.99;  
    }
}

int main() {
    std::string input;

    std::cout << "Enter a string (or type 'END' to quit):" << std::endl;

    while (true) {
        std::cout << "> ";
        std::getline(std::cin, input);

        if (input == "END") {
            break;
        }

        double extractedValue = extractNumeric(input);
        if (extractedValue == -999999.99) {
            std::cout << "The input is invalid." << std::endl;
        } else {
            std::cout << "The input is: " << std::fixed << std::setprecision(4) << extractedValue << std::endl;
        }
    }

    return 0;
}
